# Highlights

- Diagnoses open-vocabulary RGB-D target sources for manipulation.
- Separates semantic retrieval from executable 3D action targets.
- Shows crop and memory targets are more executable than box-center depth.
- Quantifies centimeter-level pick and place sensitivity.
- Adds a conservative non-cube PickSingleYCB diagnostic.
